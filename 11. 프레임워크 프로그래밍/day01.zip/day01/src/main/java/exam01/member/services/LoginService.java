package exam01.member.services;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
}
