package exam01.member.dao.sub;

import org.springframework.stereotype.Component;

@Component("memberDao2")
public class MemberDao {
}
