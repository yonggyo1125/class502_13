package exam01;

public interface Calculator {
    long factorial(long num);
}
