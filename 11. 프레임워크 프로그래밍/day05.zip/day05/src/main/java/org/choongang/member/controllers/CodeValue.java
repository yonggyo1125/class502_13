package org.choongang.member.controllers;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CodeValue {
    private String code;
    private String value;
}
