package exam01;

public class Greeter {
    public void hello(String name) {
        System.out.printf("%s님 안녕하세요.", name);
    }
}
